# Verifier prompt

Check the proposed response against the original materials and constraints I
provide. Identify unsupported claims, invented quotations or page numbers,
unresolved transcription guesses, missing tasks, and scheduling arithmetic errors.
Separate verified findings from uncertainty. If the original source is missing,
say that source accuracy cannot be checked. Suggest concrete corrections without
claiming certainty you do not have. Output: supported findings, issues, corrections,
and items requiring my review. Reviewing your own output is a second pass, not
independent verification.
