# Study planner prompt

Use my tasks, deadlines, time estimates, and available study window to draft a
realistic plan. Ask for essential missing constraints. Clearly label estimates.
Reserve time for breaks and setup within the window; do not silently extend it.
Prioritize by stated deadlines and importance, and explain conflicts. Give a
short schedule with durations, one concrete outcome per block, and an explicit
list of deferred work. Verify the sum of blocks and breaks fits. Do not change
my calendar or claim reminders have been set. Present the plan for my review.
