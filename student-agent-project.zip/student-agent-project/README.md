# Student Agent Project

A text-based collection of agent prompts and workflows for organizing coursework,
reviewing notes, planning study sessions, and adjusting when plans change.

## Status

Initial concept and prompt collection. These are instructions to copy into an AI
assistant, not executable agents or a deployed application. No automated routing,
background monitoring, calendar integration, or independent handwriting recognition
is implemented. The prompts have not yet been evaluated with real students.

## Start here

1. Copy `agents/coordinator.md` into your chosen assistant.
2. Provide your task, source material, available time, and requested output.
3. Add the specialist prompt you need. You can use the roles in one conversation;
   separate running agents are not required.
4. Review the result and correct any assumptions before using it.

| Role | Prompt | Purpose |
| --- | --- | --- |
| Coordinator | `agents/coordinator.md` | Clarify the task and choose the relevant workflow |
| Notes reviewer | `agents/notes-reviewer.md` | Interpret provided notes and flag uncertainty |
| Study planner | `agents/study-planner.md` | Draft a plan within the student's available time |
| Recovery assistant | `agents/recovery-assistant.md` | Reassess unfinished work after a disruption |
| Verifier | `agents/verifier.md` | Check source support, assumptions, and feasibility |

See `WORKFLOW.md` for handoffs and `examples/study-session.md` for a synthetic
example. Handwritten-note review requires an assistant that can accept images;
otherwise provide a transcription. The student checks uncertain passages.

## Why this project exists

Students often have course instructions, handwritten notes, deadlines, and study
plans in different places. This project explores a small, reusable set of text
instructions that students can adapt to their own courses and tools.

## Next steps

- Try the prompts against synthetic study scenarios and record failure cases.
- Revise handoffs when information is missing or contradictory.
- Evaluate note interpretation against checked transcriptions.
- Invite feedback before considering software integrations.

## Contributing and privacy

Suggest improvements through issues or pull requests. Include a synthetic example
showing the problem and expected behavior. Do not publish personal schedules,
student records, copyrighted course readings, credentials, or identifiable notes.
Only provide material to an AI service when you have permission to share it.

## Publish on GitHub

Create a public repository named `student-agent-project` and upload the extracted
contents of this folder to its root (not the ZIP itself). Commit the files and
check that the README displays correctly. This is a new text project; no users,
downloads, adoption, or eligibility for subscription programs are claimed.

## License

MIT; see `LICENSE`.
