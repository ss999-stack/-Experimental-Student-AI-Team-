# Workflow

1. **Intake:** The coordinator identifies the goal, supplied sources, constraints,
   and desired output. It asks only for information needed to proceed.
2. **Interpret:** When notes are involved, the notes reviewer separates readable
   text, interpretation, and unresolved uncertainty.
3. **Plan:** The study planner uses confirmed tasks and explicit time estimates.
   It reserves breaks and reports work that does not fit.
4. **Recover:** After a disruption, the recovery assistant uses the student's
   progress report to propose a revised plan.
5. **Verify:** The verifier checks the output against supplied sources and time
   constraints. The student decides whether to adopt the result.

## Text handoff format

- Goal:
- Sources supplied:
- Confirmed facts:
- Assumptions or uncertain readings:
- Available time and constraints:
- Proposed output:
- Items needing student review:

The user manually copies these handoffs between roles, or asks one assistant to
apply the roles in sequence. The files do not create autonomous processes.
