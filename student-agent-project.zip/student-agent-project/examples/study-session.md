# Synthetic study session

This is a hand-written illustrative example, not evidence of a model evaluation.

## Student input

I have 90 minutes. I need to review lecture notes (25 minutes), draft an outline
(35 minutes), and make flashcards (30 minutes). The outline is due tomorrow.
Reserve 5 minutes for setup and a 10-minute break. Prioritize the outline.

## Expected planning shape

| Minute offset | Activity |
| --- | --- |
| 0–5 | Setup |
| 5–40 | Draft outline |
| 40–50 | Break |
| 50–75 | Review notes |
| 75–90 | Buffer or a clearly labeled partial flashcard session |

Only 15 minutes remain for a 30-minute flashcard task. The full task cannot be
marked complete. The student can choose partial work or defer it.

## Recovery input

At minute 50, the outline is finished, but an interruption leaves only 20 minutes.

## Expected recovery behavior

Keep the outline complete. Ask whether a focused 20-minute partial notes review
is useful, or propose it with that assumption stated. Defer flashcards and the
remaining notes work. Do not claim that all original tasks still fit.

## Verification checklist

- Initial schedule totals 90 minutes, including setup and break.
- Flashcards are clearly partial or deferred.
- Recovery uses 20 minutes, not the original remaining 40.
- No real student data or adoption claims appear.
